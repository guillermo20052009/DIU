package gestionhotel.modelo;

// Enum para controlar el tipo de habitacion
public enum tipo_habitacion {
    DOBLE_INDIVIDUAL,
    DOBLE,
    JUNIOR_SUITE,
    SUITE
}
