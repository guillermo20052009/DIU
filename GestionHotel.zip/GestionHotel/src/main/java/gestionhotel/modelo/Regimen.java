package gestionhotel.modelo;

// Enum para el tipo de dieta de la reserva
public enum Regimen {
    DESAYUNO,
    MEDIA_PENSION,
    PENSION_COMPLETA
}
